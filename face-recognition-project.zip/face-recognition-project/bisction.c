#include <stdio.h>
#include <math.h>

double f(double x) {
    return x * x * x - 4 * x - 9;
}

void bisection(double a, double b, double tol) {
    double c, c_prev;
    int count = 0;

    if (f(a) * f(b) >= 0) {
        printf("Function has the same sign at the endpoints a and b.\n");
        return;
    }

    do {
        c_prev = c;
        c = (a + b) / 2;

        if (fabs(f(c)) < tol) {
            break;
        } else if (f(a) * f(c) < 0) {
            b = c;
        } else {
            a = c;
        }
        count++;
    } while (fabs(c - c_prev) > tol);

    printf("Root found at x = %lf\n", c);
    printf("Number of iterations: %d\n", count);
}

int main() {
    double a, b;
    printf("Enter the first value of the interval: ");
    scanf("%lf", &a);

    printf("Enter the second value of the interval: ");
    scanf("%lf", &b);

    double tol = 0.0001;

    bisection(a, b, tol);

    return 0;
}
