import pandas as pd
//from dictionary
data = {
    'name':[ 'Alice','Bob','Charlie','David'] ,
    'age':[25,30,35,40],
    'city':['New York','Los Angeles','Chicago','Houston']
}
df=pd.Dataframe(data)
print("DataFrame from a dictionary:")
print(df)

//from list of dictionary
data1= [
    {'name': 'Alice', 'age': 25, 'city':'New york'},
    {'name': 'Bob', 'age':30, 'city':'Los Angeles'},
    {'name': 'Charlie', 'age':35, 'city':'Chicago'},
    {'name': 'David', 'age':40, 'city':'Houston'}
     ]
df=pd.Dataframe(data1)
print("DataFrame from list of dictionary:")
print(df)

//from list of list
data2=[]

